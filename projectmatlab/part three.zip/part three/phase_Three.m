clc; clear; close all;

%% 1) Read the clean image
img = imread('text.png');

% ????? ??? ????? ??? ???? RGB
if size(img,3) == 3
    img = rgb2gray(img);
end

%% 2) Convert to binary
bw = imbinarize(img);

%% 3) Structuring element
se = strel('square',3);  % ????? ????? ????? ?? ?????

%% 4) Apply Erosion
eroded = imerode(bw,se);
imwrite(eroded,'erosion.png');

%% 5) Apply Dilation
dilated = imdilate(bw,se);
imwrite(dilated,'dilation.png');

%% 6) Apply Opening (Erosion then Dilation)
opened = imopen(bw,se);
imwrite(opened,'opening.png');

%% 7) Apply Closing (Dilation then Erosion)
closed = imclose(bw,se);
imwrite(closed,'closing.png');

%% 8) Display results
figure;
subplot(2,3,1), imshow(bw), title('Original Binary');
subplot(2,3,2), imshow(eroded), title('Erosion');
subplot(2,3,3), imshow(dilated), title('Dilation');
subplot(2,3,4), imshow(opened), title('Opening');
subplot(2,3,5), imshow(closed), title('Closing');
